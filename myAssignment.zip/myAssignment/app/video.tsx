import { Video } from "expo-av";
import { useRef, useState } from "react";
import { Button, StyleSheet, View } from "react-native";

export default function VideoScreen() {
  const video = useRef<Video>(null);
  const [status, setStatus] = useState<any>({});

  return (
    <View style={styles.container}>
      <Video
        ref={video}
        style={styles.video}
        source={{ uri: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" }}
        useNativeControls
        resizeMode="contain"
        isLooping
        onPlaybackStatusUpdate={(s) => setStatus(() => s)}
      />
      <View style={styles.buttons}>
        <Button title="Play" onPress={() => video.current?.playAsync()} />
        <Button title="Pause" onPress={() => video.current?.pauseAsync()} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: "center" },
  video: { flex: 1 },
  buttons: { flexDirection: "row", justifyContent: "space-around", margin: 10 },
});
