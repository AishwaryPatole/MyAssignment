import * as Notifications from "expo-notifications";
import { useRouter } from "expo-router";
import { useEffect } from "react";
import { Button, StyleSheet, View } from "react-native";
import { WebView } from "react-native-webview";

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

export default function HomeScreen() {
  const router = useRouter();

  useEffect(() => {
    Notifications.requestPermissionsAsync();
  }, []);

  const triggerNotification = async (message: string) => {
    await Notifications.scheduleNotificationAsync({
      content: { title: "New Alert", body: message },
      trigger: { seconds: 3 }, 
    });
  };

  return (
    <View style={styles.container}>
      <WebView source={{ uri: "https://reactnative.dev/" }} style={{ flex: 1 }} />
      <View style={styles.buttons}>
        <Button title="Notify 1" onPress={() => triggerNotification("Hello from Button 1")} />
        <Button title="Notify 2" onPress={() => triggerNotification("Hello from Button 2")} />
        <Button title="Go to Video" onPress={() => router.push("/video")} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  buttons: { padding: 10, flexDirection: "row", justifyContent: "space-around" },
});
